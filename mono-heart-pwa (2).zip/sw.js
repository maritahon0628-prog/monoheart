// ── Mono Heart Service Worker ──
// Version: bump this string to force cache refresh
const CACHE_VERSION = 'mono-heart-v1';
const CACHE_NAME = CACHE_VERSION;

// Assets to pre-cache on install
const PRECACHE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  // External CDN assets (cache on first fetch)
];

// CDN origins to cache (network-first with fallback)
const CDN_ORIGINS = [
  'https://cdn.tailwindcss.com',
  'https://cdnjs.cloudflare.com',
  'https://fonts.googleapis.com',
  'https://fonts.gstatic.com',
];

// ── Install: pre-cache app shell ──
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(PRECACHE_ASSETS).catch(err => {
        console.warn('[SW] Pre-cache failed for some assets:', err);
      }))
      .then(() => self.skipWaiting())
  );
});

// ── Activate: clean up old caches ──
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys
          .filter(key => key !== CACHE_NAME)
          .map(key => {
            console.log('[SW] Deleting old cache:', key);
            return caches.delete(key);
          })
      )
    ).then(() => self.clients.claim())
  );
});

// ── Fetch: cache strategy ──
self.addEventListener('fetch', event => {
  const req = event.request;

  // Only handle GET
  if (req.method !== 'GET') return;

  // Skip non-http(s) requests (chrome-extension, data:, etc.)
  if (!req.url.startsWith('http')) return;

  // Skip Anthropic API calls — never cache
  if (req.url.includes('anthropic.com') || req.url.includes('/v1/messages') || req.url.includes('/chat/completions')) return;

  // Skip Google Maps iframes — let browser handle
  if (req.url.includes('maps.google.com') || req.url.includes('maps.googleapis.com')) return;

  const isCDN = CDN_ORIGINS.some(origin => req.url.startsWith(origin));
  const isAppShell = req.url.includes('index.html') || req.url.endsWith('/');

  if (isAppShell) {
    // App shell: Network first, fallback to cache
    event.respondWith(
      fetch(req)
        .then(res => {
          if (res && res.status === 200) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(req, clone));
          }
          return res;
        })
        .catch(() => caches.match(req))
    );
    return;
  }

  if (isCDN) {
    // CDN assets: Cache first, fallback to network
    event.respondWith(
      caches.match(req).then(cached => {
        if (cached) return cached;
        return fetch(req).then(res => {
          if (res && res.status === 200) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(req, clone));
          }
          return res;
        }).catch(() => cached);
      })
    );
    return;
  }

  // All other requests: Network with cache fallback
  event.respondWith(
    fetch(req)
      .then(res => {
        if (res && res.status === 200) {
          const clone = res.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(req, clone));
        }
        return res;
      })
      .catch(() => caches.match(req).then(cached => cached || new Response('Offline', {
        status: 503,
        headers: { 'Content-Type': 'text/plain' }
      })))
  );
});

// ── Background sync message handler ──
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_VERSION });
  }
});
